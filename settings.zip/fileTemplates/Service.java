package io.renren.modules.${moduleName}.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.${moduleName}.entity.${className};

import java.util.Map;

/**
 *
 * @author ykq
 * @date ${DATE} ${TIME}
 */
public interface ${className}Service extends IService<${className}> {

    PageUtils queryPage(Map<String, Object> params);
}

