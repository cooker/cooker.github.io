package io.renren.modules.${moduleName}.dao;

import io.renren.modules.${moduleName}.entity.${className};
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * @author ykq
 * @date ${DATE} ${TIME}
 */
@Mapper
public interface ${className}Dao extends BaseMapper<${className}> {
	
}
