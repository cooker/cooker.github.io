package io.renren.modules.${moduleName}.controller;

import java.util.Arrays;
import java.util.Map;

import io.renren.common.validator.ValidatorUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.${moduleName}.entity.${className};
import io.renren.modules.${moduleName}.service.${className}Service;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 *
 * @author ykq
 * @date ${DATE} ${TIME}
 */
@RestController
@RequestMapping("${moduleName}/${pathName}")
public class ${className}Controller {
    @Autowired
    private ${className}Service ${classname}Service;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("${moduleName}:${pathName}:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = ${classname}Service.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("${moduleName}:${pathName}:info")
    public R info(@PathVariable("id") String id){
        ${className} ${classname} = ${classname}Service.getById(id);

        return R.ok().put("${classname}", ${classname});
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("${moduleName}:${pathName}:save")
    public R save(@RequestBody ${className} ${classname}){
        ${classname}Service.save(${classname});

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("${moduleName}:${pathName}:update")
    public R update(@RequestBody ${className} ${classname}){
        ValidatorUtils.validateEntity(${classname});
        ${classname}Service.updateById(${classname});
        
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("${moduleName}:${pathName}:delete")
    public R delete(@RequestBody String[] ids){
        ${classname}Service.removeByIds(Arrays.asList(ids));

        return R.ok();
    }

}
